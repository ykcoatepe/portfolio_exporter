from __future__ import annotations

import asyncio

from portfolio_exporter import psd_adapter


def test_snapshot_once_roundtrip(monkeypatch):
    fake_positions = [{"symbol": "AAPL", "qty": 10, "multiplier": 1}]
    fake_marks = {"AAPL": {"price": 190.5, "source": "delayed"}}
    fake_greeks = {"delta": 42.0, "gamma": 0.1, "vega": 0.2, "theta": -0.3}
    fake_risk = {"beta": 0.12, "var95_1d": 0.02, "margin_pct": 0.1, "notional": 1000.0}

    async def _positions():
        return fake_positions

    async def _marks(positions):
        assert positions is fake_positions
        return fake_marks

    async def _greeks(positions, marks):
        assert positions is fake_positions
        assert marks is fake_marks
        return fake_greeks

    async def _risk(positions, marks, greeks):
        assert greeks is fake_greeks
        return fake_risk

    fake_positions_view = {
        "single_stocks": [{"symbol": "AAPL", "qty": 10, "mark": 190.5}],
        "option_combos": [],
        "single_options": [],
    }

    monkeypatch.setattr(psd_adapter, "load_positions", _positions)
    monkeypatch.setattr(psd_adapter, "get_marks", _marks)
    monkeypatch.setattr(psd_adapter, "compute_greeks", _greeks)
    monkeypatch.setattr(psd_adapter, "compute_risk", _risk)
    monkeypatch.setattr(
        psd_adapter, "split_positions", lambda _pos, _session: fake_positions_view
    )
    monkeypatch.setattr(psd_adapter, "_resolve_session", lambda: "EXT")

    snap = asyncio.run(psd_adapter.snapshot_once())
    expected = {
        "ts",
        "session",
        "positions",
        "positions_view",
        "quotes",
        "risk",
    }
    assert expected.issubset(snap.keys())
    assert isinstance(snap["ts"], float)
    assert snap["session"] == "EXT"
    assert snap["positions"] is fake_positions
    assert snap["positions_view"] is fake_positions_view
    assert snap["quotes"] is fake_marks
    assert snap["risk"] is fake_risk


def test_snapshot_with_delayed_marks(monkeypatch):
    async def _positions():
        return [{"symbol": "MSFT", "qty": 5, "multiplier": 1}]

    async def _marks(_positions):
        return {"MSFT": {"price": 330.0, "source": "delayed"}}

    async def _greeks(_positions, marks):
        # verify nested dict is passed through
        assert marks["MSFT"]["source"] == "delayed"
        return {"delta": 0.0, "gamma": 0.0, "vega": 0.0, "theta": 0.0}

    async def _risk(_positions, marks, greeks):
        # ensure still invoked even when marks carry metadata
        return {"beta": 0.0, "var95_1d": 0.0, "margin_pct": 0.0, "notional": 0.0}

    monkeypatch.setattr(psd_adapter, "load_positions", _positions)
    monkeypatch.setattr(psd_adapter, "get_marks", _marks)
    monkeypatch.setattr(psd_adapter, "compute_greeks", _greeks)
    monkeypatch.setattr(psd_adapter, "compute_risk", _risk)
    monkeypatch.setattr(
        psd_adapter,
        "split_positions",
        lambda _pos, _session: {
            "single_stocks": [{"symbol": "MSFT", "qty": 5, "mark": 330.0}],
            "option_combos": [],
            "single_options": [],
        },
    )
    monkeypatch.setattr(psd_adapter, "_resolve_session", lambda: "EXT")

    snap = asyncio.run(psd_adapter.snapshot_once())
    assert snap["quotes"]["MSFT"]["source"] == "delayed"
    assert snap["risk"]["notional"] == 0.0
    assert snap["session"] == "EXT"
    assert isinstance(snap["positions_view"], dict)


def test_snapshot_once_fills_missing_marks_from_yf(monkeypatch):
    async def _positions():
        return [{"symbol": "AAPL", "qty": 2, "secType": "STK"}]

    async def _marks(_positions):
        return {}

    async def _greeks(_positions, _marks):
        return {"delta": 0.0, "gamma": 0.0, "vega": 0.0, "theta": 0.0}

    async def _risk(_positions, _marks, _greeks):
        return {"beta": 0.0, "var95_1d": 0.0, "margin_pct": 0.0, "notional": 0.0}

    captured = {}

    def _split_positions(pos, _session):
        captured.update(pos[0])
        return {"single_stocks": [], "option_combos": [], "single_options": []}

    import psd.datasources.yfin as yfin

    monkeypatch.setattr(psd_adapter, "load_positions", _positions)
    monkeypatch.setattr(psd_adapter, "get_marks", _marks)
    monkeypatch.setattr(psd_adapter, "compute_greeks", _greeks)
    monkeypatch.setattr(psd_adapter, "compute_risk", _risk)
    monkeypatch.setattr(psd_adapter, "split_positions", _split_positions)
    monkeypatch.setattr(psd_adapter, "_resolve_session", lambda: "EXT")
    monkeypatch.setattr(yfin, "fill_equity_marks_from_yf", lambda _syms: {"AAPL": 190.0})

    asyncio.run(psd_adapter.snapshot_once())
    assert captured["mark"] == 190.0


def test_snapshot_once_overwrites_null_mark_with_yf(monkeypatch):
    async def _positions():
        return [{"symbol": "AAPL", "qty": 2, "secType": "STK"}]

    async def _marks(_positions):
        return {"AAPL": {"price": None, "source": "delayed"}}

    async def _greeks(_positions, _marks):
        return {"delta": 0.0, "gamma": 0.0, "vega": 0.0, "theta": 0.0}

    async def _risk(_positions, _marks, _greeks):
        return {"beta": 0.0, "var95_1d": 0.0, "margin_pct": 0.0, "notional": 0.0}

    captured = {}

    def _split_positions(pos, _session):
        captured.update(pos[0])
        return {"single_stocks": [], "option_combos": [], "single_options": []}

    import psd.datasources.yfin as yfin

    monkeypatch.setattr(psd_adapter, "load_positions", _positions)
    monkeypatch.setattr(psd_adapter, "get_marks", _marks)
    monkeypatch.setattr(psd_adapter, "compute_greeks", _greeks)
    monkeypatch.setattr(psd_adapter, "compute_risk", _risk)
    monkeypatch.setattr(psd_adapter, "split_positions", _split_positions)
    monkeypatch.setattr(psd_adapter, "_resolve_session", lambda: "EXT")
    monkeypatch.setattr(yfin, "fill_equity_marks_from_yf", lambda _syms: {"AAPL": 190.0})

    asyncio.run(psd_adapter.snapshot_once())
    assert captured["mark"] == 190.0


def test_session_info_source_ignores_invalid_override(monkeypatch):
    monkeypatch.setenv("PSD_SESSION", "not-a-session")
    monkeypatch.setattr(psd_adapter, "_infer_session_from_clock", lambda: "EXT")

    session = psd_adapter._resolve_session()
    info = psd_adapter._build_session_info(session)

    assert session == "EXT"
    assert info["source"] == "clock"
