from __future__ import annotations

import pytest

from psd.ingestor.normalize import split_positions


def _stock_fixture():
    return {
        "secType": "STK",
        "symbol": "AAPL",
        "conId": 123,
        "qty": 10,
        "avg_cost": 150.0,
        "previous_close": 150.0,
        "tick": {"last": 155.0, "ts": 1_700_000_000},
        "greeks": {"delta": 10.0},
    }


def _combo_parent():
    return {
        "secType": "BAG",
        "symbol": "AAPL",
        "description": "AAPL CALL SPREAD",
        "combo_legs": [
            {"conId": 2001},
            {"conId": 2002},
        ],
    }


def _combo_leg_long():
    return {
        "secType": "OPT",
        "symbol": "AAPL",
        "conId": 2001,
        "qty": 1,
        "avg_cost": 5.0,
        "multiplier": 100,
        "right": "CALL",
        "strike": 180.0,
        "expiry": "20240119",
        "tick": {"mid": 6.0, "ts": 1_700_000_000},
        "greeks": {"delta": 0.55, "gamma": 0.02, "theta": -0.10},
    }


def _combo_leg_short():
    return {
        "secType": "OPT",
        "symbol": "AAPL",
        "conId": 2002,
        "qty": -1,
        "avg_cost": 3.0,
        "multiplier": 100,
        "right": "CALL",
        "strike": 190.0,
        "expiry": "20240119",
        "tick": {"mid": 2.5, "ts": 1_700_000_000},
        "greeks": {"delta": -0.35, "gamma": -0.01, "theta": -0.04},
    }


def _single_option():
    return {
        "secType": "OPT",
        "symbol": "MSFT",
        "conId": 3001,
        "qty": 1,
        "avg_cost": 2.0,
        "multiplier": 100,
        "right": "PUT",
        "strike": 300.0,
        "expiry": "20240216",
        "tick": {"mid": 2.6, "ts": 1_700_000_000},
        "greeks": {"delta": -0.40, "theta": -0.02},
    }


def _single_option_flat_greeks():
    return {
        "secType": "OPT",
        "symbol": "NVDA",
        "conId": 4001,
        "qty": 2,
        "avg_cost": 3.5,
        "multiplier": 100,
        "right": "CALL",
        "strike": 600.0,
        "expiry": "20240216",
        "tick": {"mid": 4.1, "ts": 1_700_000_000},
        "delta": 0.25,
        "gamma": 0.03,
        "theta": -0.01,
        "vega": 0.12,
    }


def test_split_positions_groups_stock_combo_and_single_option():
    raw_positions = [
        _stock_fixture(),
        _combo_parent(),
        _combo_leg_long(),
        _combo_leg_short(),
        _single_option(),
    ]

    result = split_positions(raw_positions, "RTH")

    singles = result["single_stocks"]
    combos = result["option_combos"]
    singles_opts = result["single_options"]

    assert len(singles) == 1
    assert singles[0]["symbol"] == "AAPL"
    assert round(singles[0]["pnl_intraday"], 2) == 50.0

    assert len(combos) == 1
    combo = combos[0]
    assert combo["combo_id"]
    assert combo["name"] == "AAPL CALL SPREAD"
    assert round(combo["pnl_intraday"], 2) == 150.0
    assert combo["day_pnl"] == pytest.approx(combo["pnl_intraday"])
    assert combo["pnl_unrealized"] == pytest.approx(150.0)
    assert combo["total_pnl"] == pytest.approx(150.0)
    assert len(combo["legs"]) == 2

    greeks_agg = combo["greeks_agg"]
    assert round(greeks_agg["delta"], 2) == 0.20
    assert round(greeks_agg["gamma"], 2) == 0.01
    assert round(greeks_agg["theta"], 2) == -0.14

    assert len(singles_opts) == 1
    assert singles_opts[0]["symbol"] == "MSFT"
    assert round(singles_opts[0]["pnl_intraday"], 2) == 60.0


def test_split_positions_fills_greeks_from_flat_fields():
    raw_positions = [_single_option_flat_greeks()]

    result = split_positions(raw_positions, "RTH")

    singles_opts = result["single_options"]
    assert len(singles_opts) == 1

    greeks = singles_opts[0].get("greeks") or {}
    assert greeks["delta"] == pytest.approx(0.25)
    assert greeks["gamma"] == pytest.approx(0.03)
    assert greeks["theta"] == pytest.approx(-0.01)
    assert greeks["vega"] == pytest.approx(0.12)


def test_split_positions_prefers_explicit_mark_without_tick():
    raw_positions = [
        {
            "secType": "STK",
            "symbol": "AAPL",
            "conId": 987,
            "qty": 5,
            "avg_cost": 10.0,
            "previous_close": 10.0,
            "price": 12.0,
            "mark_source": "manual",
            "stale_seconds": 45,
            "pnl_leg": 250.0,
        }
    ]

    result = split_positions(raw_positions, "EXT")

    assert len(result["single_stocks"]) == 1
    stock = result["single_stocks"][0]

    assert stock["mark"] == pytest.approx(12.0)
    assert stock["price_source"] == "manual"
    assert stock["stale_s"] == pytest.approx(45.0)
    assert stock["pnl_intraday"] == pytest.approx(10.0)
    assert stock["pnl_leg"] == pytest.approx(250.0)


def test_split_positions_computes_day_pnl_with_previous_close():
    raw_positions = [
        {
            "secType": "STK",
            "symbol": "AAPL",
            "conId": 999,
            "qty": 10,
            "avg_cost": 150.0,
            "previous_close": 152.0,
            "tick": {"last": 155.0, "ts": 1_700_000_000},
        }
    ]

    result = split_positions(raw_positions, "RTH")
    stock = result["single_stocks"][0]

    assert stock["pnl_intraday"] == pytest.approx(30.0)
    assert stock["pnl_unrealized"] == pytest.approx(50.0)
    assert stock["previous_close"] == pytest.approx(152.0)


def test_split_positions_skips_prev_close_without_mark():
    raw_positions = [
        {
            "secType": "STK",
            "symbol": "AAPL",
            "conId": 1001,
            "qty": 10,
            "avg_cost": 150.0,
            "previous_close": 152.0,
        }
    ]

    result = split_positions(raw_positions, "RTH")
    stock = result["single_stocks"][0]

    assert stock["mark"] == pytest.approx(150.0)
    assert stock["pnl_intraday"] == pytest.approx(0.0)
    assert stock["previous_close"] == pytest.approx(152.0)
