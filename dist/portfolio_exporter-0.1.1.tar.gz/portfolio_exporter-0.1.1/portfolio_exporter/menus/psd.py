from __future__ import annotations

"""Helpers to launch the Portfolio Sentinel Dashboard."""

import importlib
import os
import shlex
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.panel import Panel

# Primary: Vite dev server (modern dashboard)
DEV_HOST, DEV_PORT = "localhost", 5173
# Fallback: PSD backend (FastAPI)
API_HOST = "127.0.0.1"
_DEFAULT_API_PORT = 51127
MODULE_PATH = Path(__file__).resolve()
REPO_ROOT = MODULE_PATH.parents[2]
WEB_ROOT = REPO_ROOT / "apps" / "web"
DIST_INDEX = WEB_ROOT / "dist" / "index.html"
PSD_ENV_PATH = REPO_ROOT / ".psd.env"


def _api_port() -> int:
    raw = os.getenv("PSD_PORT")
    if not raw:
        raw = _load_psd_env().get("PSD_PORT")
    raw = raw or str(_DEFAULT_API_PORT)
    try:
        return int(raw)
    except (TypeError, ValueError):
        return _DEFAULT_API_PORT


_AUTO_STARTED = False
_DEFAULT_STARTUP_TIMEOUT_S = 20.0


def _dev_port() -> int:
    raw = os.getenv("PSD_DEV_PORT", str(DEV_PORT))
    try:
        return int(raw)
    except (TypeError, ValueError):
        return DEV_PORT


def _is_dev_mode() -> bool:
    """Auto-detect if Vite dev server is running on port 5173."""
    # If explicitly set, respect it
    env_val = os.getenv("PSD_DEV_MODE", "").lower()
    if env_val in ("1", "true", "yes"):
        return True
    if env_val in ("0", "false", "no"):
        return False
    if os.getenv("PYTEST_CURRENT_TEST"):
        return False
    # Auto-detect: check if Vite is running
    return _port_open(DEV_HOST, _dev_port())


def _build_uvicorn_command() -> list[str]:
    return [
        sys.executable,
        "-m",
        "uvicorn",
        "--factory",
        "psd.web.server:make_app",
        "--host",
        API_HOST,
        "--port",
        str(_api_port()),
        "--ws",
        "none",
    ]


def _uvicorn_command_display() -> str:
    return shlex.join(_build_uvicorn_command())


def _format_start_failure(exit_code: int | None) -> str:
    code = f" (exit code {exit_code})" if exit_code is not None else ""
    return (
        "Portfolio Sentinel API failed to start"
        f"{code}. Try running `{_uvicorn_command_display()}` from the repo root for details."
    )


def _startup_timeout_s() -> float:
    raw = os.getenv("PSD_API_STARTUP_TIMEOUT_S")
    if raw is None:
        return _DEFAULT_STARTUP_TIMEOUT_S
    try:
        timeout = float(raw)
    except ValueError:
        return _DEFAULT_STARTUP_TIMEOUT_S
    return max(timeout, 1.0)


def _notify_psd_error(status: Any, message: str) -> None:
    if status:
        try:
            status.update("Portfolio Sentinel failed", "red")
            console = getattr(status, "console", None)
            if console is not None:
                console.print(f"[red]{message}[/]")
                return
        except Exception:
            pass
    print(message)


def _port_open(host: str, port: int, timeout: float = 0.5) -> bool:
    """Check if a port is open, trying both IPv4 and IPv6."""
    for family in (socket.AF_INET, socket.AF_INET6):
        try:
            with socket.socket(family, socket.SOCK_STREAM) as sock:
                sock.settimeout(timeout)
                # For IPv6 localhost, use ::1
                addr = (
                    "::1"
                    if family == socket.AF_INET6 and host in ("localhost", "127.0.0.1")
                    else host
                )
                sock.connect((addr, port))
                return True
        except OSError:
            continue
    return False


def _ensure_uvicorn_runtime() -> None:
    """Install uvicorn runtime deps if they are missing."""

    missing: list[str] = []
    for module_name, package_name in ("uvicorn", "uvicorn"), ("click", "click"):
        try:
            importlib.import_module(module_name)
        except ModuleNotFoundError:
            missing.append(package_name)
    if not missing:
        return
    subprocess.check_call(
        [sys.executable, "-m", "pip", "install", *missing],
        cwd=str(REPO_ROOT),
    )


def _load_psd_env() -> dict[str, str]:
    """Load environment overrides from .psd.env if present."""

    if not PSD_ENV_PATH.exists():
        return {}

    overrides: dict[str, str] = {}
    try:
        content = PSD_ENV_PATH.read_text(encoding="utf-8")
    except OSError:
        return overrides
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        if not key:
            continue
        value = value.strip().strip("\"'")
        overrides[key] = value
    return overrides


def start_psd_dashboard() -> None:
    """Build the PSD web bundle if needed, ensure the API is live, and open /psd."""

    if not DIST_INDEX.exists():
        subprocess.check_call(["bun", "install"], cwd=str(WEB_ROOT))
        subprocess.check_call(["bun", "run", "build"], cwd=str(WEB_ROOT))

    port = _api_port()
    if _port_open(API_HOST, port):
        _open_dash_tab()
        return

    _ensure_uvicorn_runtime()
    env = os.environ.copy()
    env.update(_load_psd_env())
    proc = subprocess.Popen(
        _build_uvicorn_command(),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT,
        cwd=str(REPO_ROOT),
        env=env,
    )

    timeout_s = _startup_timeout_s()
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if _port_open(API_HOST, port):
            break
        if proc.poll() is not None:
            raise RuntimeError(_format_start_failure(proc.returncode))
        time.sleep(0.2)
    else:
        if proc.poll() is not None:
            raise RuntimeError(_format_start_failure(proc.returncode))
        raise TimeoutError(
            "Timed out waiting "
            f"({timeout_s:.1f}s) for Portfolio Sentinel API on {API_HOST}:{port}. "
            f"Run `{_uvicorn_command_display()}` for diagnostics or set "
            "PSD_API_STARTUP_TIMEOUT_S to increase the wait."
        )

    if not _port_open(API_HOST, port):
        raise RuntimeError(
            "Portfolio Sentinel API did not respond after startup. Check for firewall blocks or port conflicts."
        )

    _open_dash_tab()


def _open_dash_tab() -> None:
    if _is_dev_mode():
        url = f"http://{DEV_HOST}:{_dev_port()}/psd"
    else:
        url = f"http://{API_HOST}:{_api_port()}/psd"
    webbrowser.open_new_tab(url)


def _console_from_status(status: Any) -> Console:
    console = getattr(status, "console", None)
    if isinstance(console, Console):
        return console
    return Console()


def start_psd_fresh(status: Any, mode: str | None = None) -> None:
    from psd.menus import ops as psd_ops

    console = _console_from_status(status)
    psd_ops.stop_psd(console, force_port_kill=True)
    psd_ops.start_psd(console, mode=mode, open_browser=False)
    psd_ops.open_dashboard_when_ready(console, timeout=_startup_timeout_s())


def stop_psd_fresh(status: Any) -> None:
    from psd.menus import ops as psd_ops

    console = _console_from_status(status)
    psd_ops.stop_psd(console, force_port_kill=True)


def _prompt_psd_mode(console: Console) -> str | None:
    options = [
        "[1] User mode (built UI on backend)",
        "[2] Dev mode (Vite UI server)",
        "[3] Open Dashboard",
        "[0] Back",
    ]
    console.print(Panel("\n".join(options), title="Portfolio Sentinel Mode"))
    choice = console.input("Select mode: ").strip().lower()
    if choice in {"", "1", "user"}:
        return "user"
    if choice in {"2", "dev", "development"}:
        return "dev"
    if choice in {"3", "open"}:
        return "open"
    if choice in {"0", "back", "exit"}:
        return None
    console.print("[red]Invalid selection. Choose 0-3.[/red]")
    return None


def launch(status: Any, fmt: str) -> None:  # noqa: ARG001 - fmt reserved for future
    """Entry point used by the main menu to open the PSD dashboard."""

    global _AUTO_STARTED

    try:
        if status is None or os.getenv("PYTEST_CURRENT_TEST"):
            if _is_dev_mode():
                # In dev mode, just open the Vite dev server directly
                _open_dash_tab()
            elif not _AUTO_STARTED or not _port_open(API_HOST, _api_port()):
                _AUTO_STARTED = True
                start_psd_dashboard()
            else:
                _open_dash_tab()
            return

        console = _console_from_status(status)
        mode = _prompt_psd_mode(console)
        if mode is None:
            return
        if mode == "open":
            _open_dash_tab()
            return
        if mode == "dev":
            os.environ["PSD_DEV_MODE"] = "1"
        elif mode == "user":
            os.environ["PSD_DEV_MODE"] = "0"
        if status:
            try:
                status.update("Starting Portfolio Sentinel (fresh)", "cyan")
            except Exception:  # pragma: no cover - defensive
                pass
        start_psd_fresh(status, mode=mode)
    except Exception as exc:  # pragma: no cover - surfaced to the user below
        _AUTO_STARTED = False
        _notify_psd_error(status, str(exc))
    else:
        if status:
            try:
                status.update("Ready", "green")
            except Exception:  # pragma: no cover
                pass


def stop(status: Any, fmt: str) -> None:  # noqa: ARG001 - fmt reserved for future
    """Stop PSD processes (hard stop) from the main menu."""
    try:
        if status:
            status.update("Stopping Portfolio Sentinel", "yellow")
        stop_psd_fresh(status)
    except Exception as exc:  # pragma: no cover - surfaced to the user below
        _notify_psd_error(status, str(exc))
    else:
        if status:
            try:
                status.update("Ready", "green")
            except Exception:  # pragma: no cover
                pass
