"""Shared CLI helpers.

Provides small utilities to keep behaviour across scripts
consistent.  Each helper is intentionally tiny and free of any
third‑party dependencies so importing this module has negligible
startup cost.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

from .config import settings


def add_common_output_args(
    parser: argparse.ArgumentParser,
    *,
    include_excel: bool = False,
    defaults: dict[str, Any] | None = None,
) -> argparse.ArgumentParser:
    """Register shared output-related flags on ``parser``.

    Parameters
    ----------
    parser:
        The :class:`argparse.ArgumentParser` to augment.
    include_excel:
        When ``True`` also register ``--excel`` (opt-in, default ``False``).
    defaults:
        Optional mapping of argument name to default value.
    """

    defaults = defaults or {}
    parser.add_argument(
        "--json", action="store_true", default=defaults.get("json", False)
    )
    parser.add_argument(
        "--no-pretty", action="store_true", default=defaults.get("no_pretty", False)
    )
    parser.add_argument(
        "--no-files", action="store_true", default=defaults.get("no_files", False)
    )
    parser.add_argument("--output-dir", default=defaults.get("output_dir"))
    if include_excel:
        parser.add_argument(
            "--excel",
            action="store_true",
            default=defaults.get("excel", False),
            help="Additionally write an XLSX workbook (requires openpyxl)",
        )
    return parser


def add_common_debug_args(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    """Register shared debug flags on ``parser``."""

    parser.add_argument("--debug-timings", action="store_true")
    return parser


def resolve_output_dir(arg: str | None) -> Path:
    """Return the effective output directory.

    Preference order:
    1. Explicit argument ``arg``.
    2. ``OUTPUT_DIR`` environment variable.
    3. ``PE_OUTPUT_DIR`` environment variable (backwards compatibility).
    4. ``settings.output_dir`` from configuration.
    """

    # In test mode, prefer legacy PE_OUTPUT_DIR to simplify sandboxing of writes
    if os.getenv("PE_TEST_MODE"):
        env = os.getenv("PE_OUTPUT_DIR") or os.getenv("OUTPUT_DIR")
    else:
        env = os.getenv("OUTPUT_DIR") or os.getenv("PE_OUTPUT_DIR")
    base = arg or env or settings.output_dir
    return Path(base).expanduser()


def resolve_quiet(no_pretty: bool) -> tuple[bool, bool]:
    """Determine quiet/pretty flags.

    ``PE_QUIET=1`` forces quiet mode regardless of ``no_pretty``.
    Returns ``(quiet, pretty)``.
    """

    quiet_env = os.getenv("PE_QUIET") not in (None, "", "0")
    quiet = bool(quiet_env)
    pretty = not quiet and not no_pretty
    return quiet, pretty


def decide_file_writes(
    args: Any,
    *,
    json_only_default: bool,
    defaults: dict[str, bool],
) -> dict[str, bool]:
    """Determine which output formats should be written.

    ``defaults`` maps format names to their default enabled state.
    ``json_only_default`` controls whether ``--json`` without an
    ``--output-dir`` disables file writes.
    """

    formats = {k: bool(getattr(args, k, False)) for k in defaults}
    if getattr(args, "no_files", False):
        return {k: False for k in defaults}

    if any(formats.values()):
        return formats

    if (
        json_only_default
        and getattr(args, "json", False)
        and getattr(args, "output_dir", None) is None
    ):
        return {k: False for k in defaults}

    return defaults


def print_json(data: dict[str, Any], quiet: bool) -> None:
    """Emit JSON to STDOUT.

    Always prints compact JSON (no whitespace).  ``quiet`` is accepted so
    callers can unconditionally pass the value returned from
    :func:`resolve_quiet`; JSON is still printed in quiet mode.
    """

    txt = json.dumps(data, separators=(",", ":"))
    print(txt)
